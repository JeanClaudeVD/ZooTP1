package com.TPOO.TP1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.TPOO.TP1")
public class AppConfig {

}
