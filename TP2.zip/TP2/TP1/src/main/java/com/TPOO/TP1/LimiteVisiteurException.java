package com.TPOO.TP1;

public class LimiteVisiteurException extends Exception{

    public LimiteVisiteurException(){
        super();
    }

}
