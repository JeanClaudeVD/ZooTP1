package com.TPOO.TP1;

public enum TypeAnimal {
    chien,
    chat
}
