package com.TPOO.TP1;

import static com.TPOO.TP1.TypeAnimal.chien;

public class Chien extends Animal {

    public Chien(String nom){
        super(nom,chien);
    }
    @Override
    String getNomAnimal() {
        return super.getNomAnimal();
    }
}
