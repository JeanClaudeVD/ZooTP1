package com.TPOO.TP1;

public class AnimalDansMauvaisSecteurException extends Exception{
    public AnimalDansMauvaisSecteurException(){
        super();
    }

}
